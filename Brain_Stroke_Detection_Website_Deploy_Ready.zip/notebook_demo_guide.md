# Hosted Notebook Deployment Guide (Google Colab / Kaggle)

This guide explains how to run the **Brain Stroke Detection Using CNN and Deep Learning Models** website inside a cloud notebook environment (e.g., Google Colab, Kaggle Notebooks, or cloud virtual machines) and expose a public demo link.

---

## ⚠️ Important Note on Hosted Notebook Links

> [!WARNING]
> **Temporary Public Demo Links**:  
> Public demo links generated via cloud tunnels (such as `localtunnel`, `ngrok`, or `pyngrok`) in Google Colab or Kaggle are **ephemeral and temporary**.  
> The link remains accessible **only while the notebook cell is executing and the cloud runtime session remains active**.  
> As soon as the notebook runtime disconnects, goes idle (typically after 15–30 minutes of inactivity), or runs out of execution quota, the tunnel terminates and the public demo URL will no longer be reachable.

---

## Step-by-Step Instructions for Google Colab

### 1. Upload Project Files
Upload the project folder (`Brain_Stroke_Detection_Website`) or compress it into a `.zip` file and extract it inside Colab:
```python
# Extract uploaded project archive
!unzip -q Brain_Stroke_Detection_Website.zip -d /content/
%cd /content/Brain_Stroke_Detection_Website
```

Verify that the trained model file `model/stroke_mobilenetv2.keras` is in place:
```python
!ls -lh model/
```

### 2. Install Required Packages
```python
!pip install flask pillow numpy tensorflow
```

### 3. Expose Web Server via localtunnel
Run the Flask application as a background process and initiate `localtunnel` on port 5000:
```python
import subprocess
import time

# Start Flask in background
proc = subprocess.Popen(["python", "app.py"])
time.sleep(3)

# Display your Colab IP (required as password for localtunnel endpoint)
import urllib.request
ip = urllib.request.urlopen('https://ipv4.icanhazip.com').read().decode('utf8').strip()
print("Your public tunnel IP password is:", ip)

# Launch localtunnel
!npx localtunnel --port 5000
```

1. Click on the generated `https://xxxxxx.loca.lt` URL in the Colab output.
2. In the localtunnel prompt, paste the IP address printed above into the **"Tunnel Password"** field and submit.
3. The interactive Brain Stroke Detection website will open in full.

---

## Local Run Alternative (Permanent & Recommended)

For permanent availability during presentations, viva, and project evaluations, running the application on a local laptop or desktop is recommended:

1. Double-click **`run_website.bat`** (on Windows), or run:
   ```bash
   pip install -r requirements.txt
   python app.py
   ```
2. Navigate to `http://127.0.0.1:5000` in any web browser.
