from __future__ import annotations
import logging
import os
import sys
from pathlib import Path
from threading import Lock

import numpy as np
from flask import Flask, jsonify, render_template, request, send_from_directory
from PIL import Image, UnidentifiedImageError

# Setup directories
BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "model" / "stroke_mobilenetv2.keras"
SAMPLES_DIR = BASE_DIR / "static" / "samples"
MAX_UPLOAD_BYTES = 16 * 1024 * 1024  # 16 MB limit

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s in %(module)s: %(message)s"
)
logger = logging.getLogger("BrainStrokeApp")

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD_BYTES

_model = None
_model_lock = Lock()
_tf_available = None


def check_tf_availability():
    global _tf_available
    if _tf_available is None:
        try:
            import tensorflow as tf  # noqa: F401
            _tf_available = True
        except ImportError:
            _tf_available = False
    return _tf_available


def get_model():
    """Thread-safe lazy loader for the trained MobileNetV2 Keras model."""
    global _model
    if _model is not None:
        return _model

    with _model_lock:
        if _model is not None:
            return _model

        if not check_tf_availability():
            raise RuntimeError(
                "TensorFlow is currently loading or not installed in the active environment. "
                "Please run: pip install tensorflow keras"
            )

        if not MODEL_PATH.exists():
            raise FileNotFoundError(
                f"Model file not found at: {MODEL_PATH}. "
                "Please place 'stroke_mobilenetv2.keras' inside the 'model/' directory."
            )

        import tensorflow as tf
        logger.info(f"Loading trained MobileNetV2 model from {MODEL_PATH}...")
        # Note: compile=False as we only use the model for inference and preserve its exact weights
        _model = tf.keras.models.load_model(str(MODEL_PATH), compile=False)
        logger.info("MobileNetV2 model successfully loaded into memory.")
        return _model


@app.get("/")
def index():
    """Render the main educational website."""
    return render_template("index.html")


@app.get("/api/health")
def health():
    """Return backend status, model file status, and TF availability."""
    tf_ready = check_tf_availability()
    model_exists = MODEL_PATH.exists()
    model_loaded = _model is not None

    return jsonify({
        "status": "ready" if (tf_ready and model_exists) else "degraded",
        "tensorflow_available": tf_ready,
        "model_file_exists": model_exists,
        "model_file_path": str(MODEL_PATH),
        "model_is_loaded": model_loaded,
        "python_version": sys.version.split()[0]
    })


@app.get("/api/samples")
def list_samples():
    """Return available authentic sample CT scans for instant testing."""
    samples = []
    if SAMPLES_DIR.exists():
        for file in sorted(SAMPLES_DIR.glob("*.*")):
            if file.suffix.lower() in {".jpg", ".jpeg", ".png", ".webp"}:
                is_stroke = "stroke" in file.stem.lower()
                samples.append({
                    "id": file.stem,
                    "filename": file.name,
                    "label": "Stroke CT Scan" if is_stroke else "Normal CT Scan",
                    "category": "stroke" if is_stroke else "normal",
                    "url": f"/static/samples/{file.name}"
                })
    return jsonify(samples)


@app.post("/api/predict")
def predict():
    """
    Accepts an uploaded brain CT image or sample reference.
    Resizes to 224x224 RGB, runs MobileNetV2 inference,
    and returns Normal vs Stroke percentage scores with uncertainty analysis.
    """
    image = None
    source_name = "Upload"

    # 1. Check for sample selection
    sample_name = request.form.get("sample_name")
    if sample_name:
        sample_file = SAMPLES_DIR / Path(sample_name).name
        if not sample_file.exists():
            return jsonify({"error": f"Sample file '{sample_name}' not found."}), 404
        try:
            image = Image.open(sample_file)
            source_name = sample_file.name
        except Exception as exc:
            return jsonify({"error": f"Failed to load sample image: {exc}"}), 500

    # 2. Check for uploaded file
    elif "image" in request.files:
        upload = request.files["image"]
        if not upload.filename:
            return jsonify({"error": "Please select a brain CT scan image to upload."}), 400
        source_name = upload.filename
        try:
            image = Image.open(upload.stream)
        except (UnidentifiedImageError, OSError, ValueError):
            return jsonify({
                "error": "The selected file is not a valid image. Please upload a JPG, PNG, BMP, or WEBP brain CT scan."
            }), 400
    else:
        return jsonify({"error": "No image was provided. Please upload a file or choose a sample CT scan."}), 400

    # Validate image format
    if image.format not in {"JPEG", "PNG", "BMP", "WEBP", "MPO", None} and not hasattr(image, "mode"):
        return jsonify({"error": "Unsupported image format. Please use JPG, PNG, BMP, or WEBP."}), 415

    try:
        # Preprocessing: convert to RGB and resize to exactly 224x224
        # MobileNetV2 architecture expects 224x224 RGB input
        # Note: Model includes its own internal preprocessing layers
        original_size = image.size
        processed_image = image.convert("RGB").resize((224, 224), Image.Resampling.BILINEAR)
        pixels = np.asarray(processed_image, dtype=np.float32)

        # Run inference using the trained MobileNetV2 model
        model = get_model()
        batch_input = np.expand_dims(pixels, axis=0)
        raw_output = model.predict(batch_input, verbose=0)
        scores = np.asarray(raw_output).reshape(-1)

        if scores.size == 0 or not np.isfinite(scores[0]):
            return jsonify({"error": "The model returned an invalid or non-finite output."}), 500

        # Model output is a binary sigmoid score representing Stroke probability
        stroke_prob = float(np.clip(scores[0], 0.0, 1.0))
        normal_prob = 1.0 - stroke_prob

        stroke_pct = round(stroke_prob * 100, 1)
        normal_pct = round(normal_prob * 100, 1)

        predicted_class = "Stroke" if stroke_prob >= 0.50 else "Normal"
        confidence_margin = abs(stroke_prob - normal_prob)

        # Determine if scores are close (uncertain estimate threshold: margin < 0.15 i.e. within 15%)
        is_uncertain = confidence_margin < 0.15
        if is_uncertain:
            interpretation = "Close scores — uncertain estimate"
            uncertainty_explanation = (
                f"The difference between Stroke ({stroke_pct}%) and Normal ({normal_pct}%) "
                f"is only {round(confidence_margin * 100, 1)}% (< 15%). "
                "Because these scores are very close, this prediction is classified as highly uncertain. "
                "The neural network does not have strong feature distinctiveness for this slice."
            )
        else:
            interpretation = f"Higher score: {predicted_class}"
            uncertainty_explanation = (
                f"Clear score separation: {predicted_class} leads by "
                f"{round(confidence_margin * 100, 1)}%. (Educational demonstration estimate)."
            )

        return jsonify({
            "source_name": source_name,
            "original_dimensions": f"{original_size[0]} × {original_size[1]}",
            "model_input_dimensions": "224 × 224 × 3",
            "predicted_class": predicted_class,
            "stroke_score": stroke_pct,
            "normal_score": normal_pct,
            "confidence_margin": round(confidence_margin * 100, 1),
            "is_uncertain": is_uncertain,
            "interpretation": interpretation,
            "uncertainty_explanation": uncertainty_explanation,
            "model_architecture": "MobileNetV2 (Transfer Learning)"
        })

    except FileNotFoundError as exc:
        logger.error(f"Model file missing: {exc}")
        return jsonify({
            "error": "The trained model file 'stroke_mobilenetv2.keras' is not found in the model/ directory. "
                     "Please ensure the model file is placed at: model/stroke_mobilenetv2.keras"
        }), 503
    except RuntimeError as exc:
        logger.error(f"Runtime error: {exc}")
        return jsonify({"error": str(exc)}), 503
    except Exception as exc:
        logger.exception("Inference failed")
        return jsonify({
            "error": f"An error occurred during model prediction: {str(exc)}"
        }), 500


@app.errorhandler(413)
def file_too_large(_error):
    return jsonify({
        "error": "The uploaded CT image is too large. Please select an image under 16 MB."
    }), 413


@app.errorhandler(404)
def not_found(_error):
    return jsonify({"error": "Resource not found."}), 404


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    host = os.environ.get("HOST", "0.0.0.0")
    print("=" * 70)
    print("  Brain Stroke Detection Using CNN and Deep Learning Models")
    print(f"  Local Web Server running at: http://127.0.0.1:{port} and http://localhost:{port}")
    print(f"  Model Path: {MODEL_PATH}")
    print("=" * 70)
    try:
        get_model()
        print("  [SUCCESS] MobileNetV2 model preloaded and ready for immediate predictions.")
    except Exception as e:
        print(f"  [NOTE] Model will load on first request: {e}")
    app.run(host=host, port=port, debug=False)
