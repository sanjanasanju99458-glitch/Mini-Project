@echo off
cd /d "%~dp0"
title Brain Stroke Detection Using CNN and Deep Learning Models - AIT Mini-Project
color 0B
echo ===============================================================================
echo   BRAIN STROKE DETECTION USING CNN AND DEEP LEARNING MODELS
echo   Department of Artificial Intelligence and Machine Learning Engineering
echo   Adichunchanagiri Institute of Technology
echo ===============================================================================
echo.
echo [1/3] Checking environment and trained model file...
if not exist "model\stroke_mobilenetv2.keras" (
    echo [ERROR] Model file 'model\stroke_mobilenetv2.keras' was not found!
    echo Please make sure the model file is placed in the 'model' directory.
    pause
    exit /b 1
)
echo [OK] Model file verified at: model\stroke_mobilenetv2.keras
echo.
echo [2/3] Launching web browser in 2 seconds...
start "" http://127.0.0.1:5000
echo.
echo [3/3] Starting local Flask server on port 5000...
echo Press Ctrl+C in this terminal window to stop the server at any time.
echo ===============================================================================
python app.py
pause
