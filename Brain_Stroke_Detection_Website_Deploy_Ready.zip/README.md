# Brain Stroke Detection Using CNN and Deep Learning Models

An educational mini-project website demonstrating deep learning classification of axial brain CT scans into **Normal** and **Stroke** classes. Developed by undergraduate engineering students in the Department of Artificial Intelligence and Machine Learning Engineering at **Adichunchanagiri Institute of Technology**.

---

## ⚠️ Critical Medical Disclaimer & Responsible Use

> [!CAUTION]
> **STUDENT EDUCATIONAL PROTOTYPE ONLY — NOT FOR MEDICAL USE**  
> This software is a student coursework demonstration and educational prototype. It has **NOT** undergone clinical trials, health authority regulatory clearance, or clinical validation.  
> **DO NOT** use this software or its outputs for medical diagnosis, treatment planning, emergency triage, or clinical decision-making.  
> If you or someone you know is experiencing stroke symptoms, call emergency medical services immediately (e.g., 911 / 112 / 108).

---

## 👥 Project Team & Institution

- **Sanjana M.A.** — `4AI24AI042`
- **Sheethal C.P.** — `4AI24AI045`
- **Harshitha R.C.** — `4AI24AI019`
- **Sneha A. Shetty** — `4AI24AI049`

- **Project Guide:** Mrs. Priyanka M.C., B.E., M.Tech.
- **Department:** Department of Artificial Intelligence and Machine Learning Engineering
- **Institution:** Adichunchanagiri Institute of Technology, Chikkamagaluru, Karnataka, India

---

## 📊 Dataset Summary

- **Source:** *Brain Stroke Prediction CT Scan Image Dataset* by **iashiqul** on Kaggle.
- **Modality:** Non-contrast head CT (axial slices).
- **Total Images:** 2,515 brain CT images.
- **Dataset Partitioning:**
  - **Training Split (1,843 images):** 1,087 Normal and 756 Stroke.
  - **Validation Split (235 images):** Used for checkpoint selection.
  - **Held-Out Test Split (437 images):** 307 Normal and 130 Stroke.

---

## 🧠 Methodology & Deep Learning Models

Two convolutional neural network strategies were developed and evaluated:

1. **Custom CNN (Baseline):**
   - 4 Convolutional stages (32, 64, 128, 256 filters) with ReLU activations.
   - Max pooling (2 × 2) downsampling.
   - Dropout layers (0.3 and 0.5) to mitigate overfitting.
   - Dense hidden layer (128 units) with a single Sigmoid output neuron.
   - **Test Accuracy:** **61.8%**

2. **MobileNetV2 (Transfer Learning - Deployed):**
   - Pre-trained backbone on ImageNet utilizing inverted residual bottlenecks and depthwise separable convolutions.
   - Preserves spatial and anatomical feature hierarchies while maintaining computational efficiency.
   - Global Average Pooling 2D + Dropout(0.2) + Sigmoid classification unit.
   - Internal input rescaling layers embedded directly inside the model graph.
   - **Test Accuracy:** **70.0%** (+8.2% improvement over Custom CNN).

---

## 📈 Evaluation Results & Confusion Matrix

Evaluated on the held-out test split of 437 images (307 Normal, 130 Stroke):

### Key Performance Metrics (MobileNetV2):
| Metric | Value | Interpretation |
| :--- | :--- | :--- |
| **Test Accuracy** | **70.0%** | 306 out of 437 test scans correctly classified |
| **Stroke Recall (Sensitivity)** | **0.63** | 82 of 130 actual strokes detected (63.0%) |
| **Stroke Precision** | **0.50** | 82 of 165 stroke predictions confirmed (50.0%) |
| **Stroke F1-Score** | **0.56** | Harmonic mean of precision and recall |

### Confusion Matrix `[[224, 83], [48, 82]]`:
| Actual \ Predicted | Predicted NORMAL | Predicted STROKE | Total Actual |
| :--- | :---: | :---: | :---: |
| **Actual NORMAL** | **224** (True Negative) | **83** (False Positive) | 307 |
| **Actual STROKE** | **48** (False Negative) | **82** (True Positive) | 130 |
| **Total Predicted** | 272 | 165 | **437 Total** |

---

## 🔍 Uncertainty Margin Handling

The application computes both Normal and Stroke class probabilities:
$$\text{Margin} = |\text{Score}_{\text{Stroke}} - \text{Score}_{\text{Normal}}|$$

- If $\text{Margin} < 15\%$ (e.g. 52% vs 48%), the system highlights:
  > **⚠️ Close scores — uncertain estimate.** The model lacks clear feature distinctiveness on this slice.
- If $\text{Margin} \ge 15\%$, the model presents the leading class estimate with higher confidence.

---

## 🚀 Quick Start Guide (Running Locally)

### Prerequisites:
- Python 3.9 to 3.14
- Web browser (Chrome, Edge, Firefox, Brave)

### One-Click Launch (Windows):
Double-click `run_website.bat` in the project directory.

### Manual Terminal Launch:
```bash
# 1. Clone or navigate to the project directory
cd Brain_Stroke_Detection_Website

# 2. Install required packages
pip install -r requirements.txt

# 3. Ensure the trained model file is in place
# Path: model/stroke_mobilenetv2.keras

# 4. Run the Flask web application
python app.py
```

Open `http://127.0.0.1:5000` in your web browser.

---

## ☁️ Hosted Notebooks (Google Colab / Kaggle)

For instructions on deploying the application from Google Colab or Kaggle via temporary tunnels (localtunnel/ngrok), refer to [`notebook_demo_guide.md`](notebook_demo_guide.md).  
*Note: Public demo links generated in hosted notebooks remain available only while the notebook runtime is active.*
