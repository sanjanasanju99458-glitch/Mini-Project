# Permanent 24/7 Cloud Deployment Guide

This guide explains how to get a **100% free, permanent public URL** that remains online and accessible at any time (from phones, laptops, and external computers) without needing your personal computer to be turned on.

---

## 🌟 Method 1: Hugging Face Spaces (Recommended for Full Python/Keras Backend)
*Permanent URL Format:* `https://huggingface.co/spaces/YOUR_USERNAME/brain-stroke-detection`  
*Direct Web URL:* `https://YOUR_USERNAME-brain-stroke-detection.hf.space`

Hugging Face Spaces provides **16 GB RAM + 2 vCPU completely free** with **zero expiration** (stays online 24/7/365).

### 3-Step Setup:
1. **Create Free Account & Space**:
   - Go to [huggingface.co](https://huggingface.co) and sign up (free).
   - Click on **New Space** ([huggingface.co/new-space](https://huggingface.co/new-space)).
   - Enter Space name: `brain-stroke-detection`.
   - Under **Space SDK**, select **Docker** (Blank).
   - Visibility: **Public**.
   - Click **Create Space**.

2. **Upload Project Files**:
   - In your new Space, click on the **Files** tab $\rightarrow$ click **Add file** $\rightarrow$ **Upload files**.
   - Drag and drop the following files & folders from `Brain_Stroke_Detection_Website`:
     - `Dockerfile`
     - `app.py`
     - `requirements.txt`
     - `model/` (contains `stroke_mobilenetv2.keras`)
     - `templates/` (contains `index.html`)
     - `static/` (contains `css/`, `js/`, `samples/`, `model/`)
   - Click **Commit changes to main**.

3. **Live Forever**:
   - Hugging Face will automatically build your Docker container in ~2 minutes.
   - Your permanent website is now live 24/7 at:
     `https://YOUR_USERNAME-brain-stroke-detection.hf.space`

---

## ⚡ Method 2: Vercel / Netlify (Instant 30-Second Drag & Drop)
*Permanent URL Format:* `https://brain-stroke-detection-xxxx.vercel.app`

Because we have equipped the website with an in-browser **ONNX Runtime Web engine** (`stroke_mobilenetv2.onnx`), the entire model and interface can run serverless in the browser with **100.0% uptime and zero maintenance**:

1. Open [vercel.com](https://vercel.com) or [netlify.com](https://netlify.com) and create a free account.
2. In the dashboard, click **Add New Project** $\rightarrow$ drag and drop the `Brain_Stroke_Detection_Website` folder.
3. Click **Deploy**.
4. Within 15 seconds, Vercel gives you an active permanent public URL ending in `.vercel.app`.

---

## 🐙 Method 3: GitHub Pages (100% Free & Permanent)
*Permanent URL Format:* `https://YOUR_USERNAME.github.io/brain-stroke-detection/`

1. Create a repository on [github.com](https://github.com) named `brain-stroke-detection`.
2. Upload the contents of `Brain_Stroke_Detection_Website`.
3. Go to repository **Settings** $\rightarrow$ **Pages** (on the left menu).
4. Under **Branch**, select `main` and folder `/ (root)`, then click **Save**.
5. Within 1 minute, your website is live permanently at:
   `https://YOUR_USERNAME.github.io/brain-stroke-detection/`
