/**
 * Brain Stroke Detection Using CNN and Deep Learning Models
 * Client-side Controller & Interactive UI Handler
 */

document.addEventListener('DOMContentLoaded', () => {
  // DOM Elements - Inputs & Dropzone
  const fileInput = document.getElementById('file-input');
  const dropzone = document.getElementById('dropzone');
  const dropzonePrompt = document.getElementById('dropzone-prompt');
  const previewContainer = document.getElementById('preview-container');
  const previewImage = document.getElementById('preview-image');
  const previewMeta = document.getElementById('preview-meta');
  const previewDimensions = document.getElementById('preview-dimensions');
  const btnClassify = document.getElementById('btn-classify');
  const btnClear = document.getElementById('btn-clear');
  const alertBox = document.getElementById('alert-box');

  // DOM Elements - Results
  const resultPlaceholder = document.getElementById('result-placeholder');
  const resultContent = document.getElementById('result-content');
  const predictedBanner = document.getElementById('predicted-banner');
  const predictedClassText = document.getElementById('predicted-class-text');
  const predictedTag = document.getElementById('predicted-tag');
  const strokeScoreVal = document.getElementById('stroke-score-val');
  const normalScoreVal = document.getElementById('normal-score-val');
  const strokeScoreFill = document.getElementById('stroke-score-fill');
  const normalScoreFill = document.getElementById('normal-score-fill');
  const uncertaintyCard = document.getElementById('uncertainty-card');
  const uncertaintyTitle = document.getElementById('uncertainty-title');
  const uncertaintyDesc = document.getElementById('uncertainty-desc');
  const telemetryDims = document.getElementById('telemetry-dims');
  const telemetrySource = document.getElementById('telemetry-source');
  const telemetryMargin = document.getElementById('telemetry-margin');

  // Sample Buttons
  const sampleButtons = document.querySelectorAll('.sample-btn');

  // Mobile Menu
  const menuToggle = document.getElementById('menu-toggle');
  const navMenu = document.getElementById('nav-menu');

  // State
  let currentFile = null;
  let currentSampleName = null;
  let objectUrl = null;

  // -------------------------------------------------------------------------
  // 1. Mobile Menu Toggle
  // -------------------------------------------------------------------------
  if (menuToggle && navMenu) {
    menuToggle.addEventListener('click', () => {
      navMenu.classList.toggle('open');
    });

    // Close menu when clicking any nav link
    navMenu.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', () => {
        navMenu.classList.remove('open');
      });
    });
  }

  // -------------------------------------------------------------------------
  // 2. Alert Handling
  // -------------------------------------------------------------------------
  function showAlert(message, type = 'danger') {
    alertBox.textContent = message;
    alertBox.className = `alert-box alert-${type}`;
    alertBox.classList.remove('hidden');
  }

  function hideAlert() {
    alertBox.textContent = '';
    alertBox.className = 'alert-box hidden';
  }

  // -------------------------------------------------------------------------
  // 3. Image Selection & Preview
  // -------------------------------------------------------------------------
  function displayImage(fileOrUrl, isSample = false, sampleName = '') {
    hideAlert();
    resetResultsView();

    if (isSample) {
      currentFile = null;
      currentSampleName = sampleName;
      if (objectUrl) {
        URL.revokeObjectURL(objectUrl);
        objectUrl = null;
      }
      previewImage.src = fileOrUrl;
      previewMeta.textContent = `Sample: ${sampleName}`;
      previewDimensions.textContent = 'Authentic Dataset Slice';
    } else {
      currentSampleName = null;
      currentFile = fileOrUrl;

      // Validate MIME type
      const validTypes = ['image/jpeg', 'image/png', 'image/bmp', 'image/webp'];
      if (!validTypes.includes(fileOrUrl.type) && !fileOrUrl.name.match(/\.(jpg|jpeg|png|bmp|webp)$/i)) {
        showAlert('Please upload a valid image file (JPG, PNG, BMP, or WEBP).');
        return;
      }

      // Max 16 MB
      if (fileOrUrl.size > 16 * 1024 * 1024) {
        showAlert('Image file size exceeds the 16 MB limit. Please select a smaller file.');
        return;
      }

      if (objectUrl) URL.revokeObjectURL(objectUrl);
      objectUrl = URL.createObjectURL(fileOrUrl);
      previewImage.src = objectUrl;

      const sizeKb = (fileOrUrl.size / 1024).toFixed(1);
      previewMeta.textContent = `${fileOrUrl.name} (${sizeKb} KB)`;
      previewDimensions.textContent = 'Local Image File';
    }

    dropzonePrompt.classList.add('hidden');
    previewContainer.classList.remove('hidden');
    btnClassify.disabled = false;
  }

  // -------------------------------------------------------------------------
  // 4. Dropzone & File Input Events
  // -------------------------------------------------------------------------
  dropzone.addEventListener('click', (e) => {
    // If clicking browse button or area
    if (!previewContainer.contains(e.target) || e.target.id === 'preview-image') {
      fileInput.click();
    }
  });

  fileInput.addEventListener('change', (e) => {
    if (e.target.files && e.target.files[0]) {
      clearActiveSampleButtons();
      displayImage(e.target.files[0]);
    }
  });

  // Drag and drop listeners
  ['dragenter', 'dragover'].forEach(eventName => {
    dropzone.addEventListener(eventName, (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropzone.classList.add('drag-active');
    });
  });

  ['dragleave', 'drop'].forEach(eventName => {
    dropzone.addEventListener(eventName, (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropzone.classList.remove('drag-active');
    });
  });

  dropzone.addEventListener('drop', (e) => {
    if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]) {
      clearActiveSampleButtons();
      displayImage(e.dataTransfer.files[0]);
    }
  });

  // -------------------------------------------------------------------------
  // 5. Sample Buttons Handler
  // -------------------------------------------------------------------------
  function clearActiveSampleButtons() {
    sampleButtons.forEach(btn => btn.classList.remove('active'));
  }

  sampleButtons.forEach(button => {
    button.addEventListener('click', (e) => {
      e.stopPropagation();
      clearActiveSampleButtons();
      button.classList.add('active');

      const sampleSrc = button.getAttribute('data-src');
      const sampleFile = button.getAttribute('data-filename');
      displayImage(sampleSrc, true, sampleFile);
    });
  });

  // -------------------------------------------------------------------------
  // 6. Reset & Clear
  // -------------------------------------------------------------------------
  function resetAll() {
    currentFile = null;
    currentSampleName = null;
    fileInput.value = '';
    if (objectUrl) {
      URL.revokeObjectURL(objectUrl);
      objectUrl = null;
    }
    previewImage.removeAttribute('src');
    previewContainer.classList.add('hidden');
    dropzonePrompt.classList.remove('hidden');
    btnClassify.disabled = true;
    hideAlert();
    clearActiveSampleButtons();
    resetResultsView();
  }

  function resetResultsView() {
    resultContent.classList.add('hidden');
    resultPlaceholder.classList.remove('hidden');
    strokeScoreFill.style.width = '0%';
    normalScoreFill.style.width = '0%';
  }

  btnClear.addEventListener('click', resetAll);

  // -------------------------------------------------------------------------
  // 7. Prediction & API Submission
  // -------------------------------------------------------------------------
  btnClassify.addEventListener('click', async () => {
    if (!currentFile && !currentSampleName) {
      showAlert('Please upload or select a brain CT scan image first.');
      return;
    }

    hideAlert();
    btnClassify.disabled = true;
    const originalText = btnClassify.innerHTML;
    btnClassify.innerHTML = '<span class="spinner-icon"></span> Analyzing CT Scan...';

    const formData = new FormData();
    if (currentSampleName) {
      formData.append('sample_name', currentSampleName);
    } else if (currentFile) {
      formData.append('image', currentFile);
    }

    try {
      let data = null;

      // Try Backend API first
      try {
        const response = await fetch('/api/predict', {
          method: 'POST',
          body: formData
        });
        if (response.ok) {
          data = await response.json();
        }
      } catch (networkErr) {
        console.log('Backend not reachable, falling back to client-side ONNX runtime...', networkErr);
      }

      // If backend was not available or not running (e.g. GitHub Pages / Vercel static deployment)
      if (!data) {
        btnClassify.innerHTML = '<span class="spinner-icon"></span> Running In-Browser Model...';
        data = await runClientSideInference();
      }

      // Populate Result Dashboard
      renderPredictionResults(data);

    } catch (err) {
      showAlert(err.message || 'An unexpected error occurred during prediction.');
    } finally {
      btnClassify.disabled = false;
      btnClassify.innerHTML = originalText;
    }
  });

  // -------------------------------------------------------------------------
  // 7b. Client-Side ONNX Fallback for 100% Serverless Static Hosting (Vercel/GitHub Pages)
  // -------------------------------------------------------------------------
  let ortSession = null;
  async function getOrtSession() {
    if (!ortSession && window.ort) {
      const candidatePaths = [
        'static/model/stroke_mobilenetv2.onnx',
        '/static/model/stroke_mobilenetv2.onnx',
        './static/model/stroke_mobilenetv2.onnx',
        'model/stroke_mobilenetv2.onnx'
      ];
      for (const p of candidatePaths) {
        try {
          ortSession = await ort.InferenceSession.create(p, { executionProviders: ['wasm'] });
          if (ortSession) break;
        } catch (e) {
          // try next path
        }
      }
    }
    return ortSession;
  }

  async function runClientSideInference() {
    const session = await getOrtSession();
    if (!session) {
      throw new Error('Could not connect to prediction server or initialize browser model.');
    }

    const canvas = document.createElement('canvas');
    canvas.width = 224;
    canvas.height = 224;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(previewImage, 0, 0, 224, 224);
    const imgData = ctx.getImageData(0, 0, 224, 224).data;

    // MobileNetV2 takes [1, 224, 224, 3] float32 in [0, 255]
    const floatData = new Float32Array(1 * 224 * 224 * 3);
    let p = 0;
    for (let i = 0; i < imgData.length; i += 4) {
      floatData[p++] = imgData[i];     // R
      floatData[p++] = imgData[i + 1]; // G
      floatData[p++] = imgData[i + 2]; // B
    }

    const inputName = session.inputNames[0];
    const inputTensor = new ort.Tensor('float32', floatData, [1, 224, 224, 3]);
    const feeds = {};
    feeds[inputName] = inputTensor;

    const results = await session.run(feeds);
    const outputName = session.outputNames[0];
    const outputData = results[outputName].data;

    const strokeProb = Math.min(Math.max(outputData[0], 0.0), 1.0);
    const normalProb = 1.0 - strokeProb;

    const stroke_pct = Math.round(strokeProb * 1000) / 10;
    const normal_pct = Math.round(normalProb * 1000) / 10;
    const predicted_class = strokeProb >= 0.5 ? 'Stroke' : 'Normal';
    const confidence_margin = Math.round(Math.abs(strokeProb - normalProb) * 1000) / 10;
    const is_uncertain = confidence_margin < 15.0;

    return {
      source_name: currentSampleName || (currentFile ? currentFile.name : 'Brain CT Scan'),
      original_dimensions: `${previewImage.naturalWidth || 224} × ${previewImage.naturalHeight || 224}`,
      model_input_dimensions: '224 × 224 × 3',
      predicted_class: predicted_class,
      stroke_score: stroke_pct,
      normal_score: normal_pct,
      confidence_margin: confidence_margin,
      is_uncertain: is_uncertain,
      interpretation: is_uncertain ? 'Close scores — uncertain estimate' : `Higher score: ${predicted_class}`,
      uncertainty_explanation: is_uncertain
        ? `The difference between Stroke (${stroke_pct}%) and Normal (${normal_pct}%) is only ${confidence_margin}% (< 15%). Because these scores are very close, this prediction is classified as highly uncertain. The neural network does not have strong feature distinctiveness for this slice.`
        : `Clear score separation: ${predicted_class} leads by ${confidence_margin}%. (Educational demonstration estimate).`,
      model_architecture: 'MobileNetV2 (ONNX In-Browser Inference)'
    };
  }

  // -------------------------------------------------------------------------
  // 8. Render Prediction Results
  // -------------------------------------------------------------------------
  function renderPredictionResults(data) {
    const isStroke = data.predicted_class === 'Stroke';
    const isUncertain = data.is_uncertain;

    // 1. Predicted Class Banner
    predictedClassText.textContent = data.predicted_class.toUpperCase();
    predictedBanner.className = `predicted-banner ${isStroke ? 'banner-stroke' : 'banner-normal'}`;

    predictedTag.textContent = isStroke ? 'High Risk Indicator' : 'Normal / Low Risk';
    predictedTag.className = `banner-tag ${isStroke ? 'tag-stroke' : 'tag-normal'}`;

    // 2. Score Bar Values
    strokeScoreVal.textContent = `${data.stroke_score.toFixed(1)}%`;
    normalScoreVal.textContent = `${data.normal_score.toFixed(1)}%`;

    // Animate Fill Bars
    setTimeout(() => {
      strokeScoreFill.style.width = `${data.stroke_score}%`;
      normalScoreFill.style.width = `${data.normal_score}%`;
    }, 50);

    // 3. Uncertainty Box
    if (isUncertain) {
      uncertaintyCard.className = 'uncertainty-card uncertainty-uncertain';
      uncertaintyTitle.innerHTML = '⚠️ Close Scores — Uncertain Estimate';
      uncertaintyDesc.textContent = data.uncertainty_explanation;
    } else {
      uncertaintyCard.className = 'uncertainty-card uncertainty-decisive';
      uncertaintyTitle.innerHTML = '✓ Decisive Classification Margin';
      uncertaintyDesc.textContent = data.uncertainty_explanation;
    }

    // 4. Telemetry
    telemetryDims.textContent = data.original_dimensions || '224 × 224';
    telemetrySource.textContent = data.source_name;
    telemetryMargin.textContent = `${data.confidence_margin.toFixed(1)}%`;

    // 5. Show results container
    resultPlaceholder.classList.add('hidden');
    resultContent.classList.remove('hidden');

    // Smooth scroll into view on small screens
    if (window.innerWidth < 850) {
      resultContent.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }

  // -------------------------------------------------------------------------
  // 9. Initial Health Check & System Status
  // -------------------------------------------------------------------------
  async function checkSystemHealth() {
    try {
      const res = await fetch('/api/health');
      const health = await res.json();
      const statusPill = document.getElementById('status-pill');
      if (statusPill) {
        if (health.model_file_exists) {
          statusPill.innerHTML = '<span class="status-dot"></span> MobileNetV2 Ready';
          statusPill.title = `Model loaded from ${health.model_file_path}`;
        } else {
          statusPill.innerHTML = '<span class="status-dot" style="background:#e11d48;box-shadow:none;"></span> Model File Missing';
          statusPill.title = 'Please ensure stroke_mobilenetv2.keras is placed in model/ directory.';
        }
      }
    } catch {
      // Backend not yet reachable or starting up
    }
  }

  checkSystemHealth();
});
